# 修改
1. border更新
2. list的active
3. animation和icon
。。。

# 整合
1. tag和dot
2. layout
3. action-sheet
4. carousel
5. selector
6. radio
7. range 
8. input

popup
search content

ratchet push.js 这样的页面切换效果功能
http://www.sitepoint.com/ratchets-push-js-prototyping-mobile-apps-multiple-screens/

外部用户会用到 我们不会用到的组件

http://mqq.oa.com/custom.html


	basic:
	包含以下组件: 
	
	//  基础样式    
	    "base/reset",
	    "base/type",
	    "base/icon",
	
	// 辅助类    
	    "util/border",
	    "util/arrowlink",
	    "util/nowrap",
	    "util/placehold",
	    "util/grid",
	    "util/whitespace",
	    "util/layout",
	
	// UI 组件
	    "component/avatar",
	    "component/btn",
	    "component/btn-group",
	    "component/list",
	    "component/slider", 
	    "component/panel",
	    "component/tab",
	    "component/loading",
	    "component/notice",
	    "component/poptips",
	    "component/newstips",
	    "component/dialog",
	    "component/searchbar";
	    
    vip: 包含以下组件: 
    
        "vip/ui-icon-qq",
	    "vip/ui-icon-qqlevel",
	    "vip/ui-icon-viplevel",
	    "vip/ui-btn-vip",
	    "vip/ui-tooltips-vip";
	    
    global: 包含basic和vip
    
    frozen:
    
	//  基础样式    
	    "base/reset",
	    "base/type",
	    "base/icon",
	
	// 辅助类    
	    "util/border",
	    "util/arrowlink",
	    "util/nowrap",
	    "util/placehold",
	    "util/grid",
	    "util/whitespace",
	    "util/justify",
	    "util/layout",
	
	// UI 组件
	    "component/badge",
	    "component/reddot",
	    "component/avatar",
	    "component/label",
	    "component/tag",
	    "component/btn",
	    "component/btn-group",
	    "component/tips", 
	    "component/newstips",
	    "component/tooltips", 
	    "component/table",
	    "component/list",
	    "component/notice",
	    "component/form",
	    "component/checkbox",
	    "component/switch",
	    "component/radio",
	    "component/select",
	    "component/input",
	    "component/searchbar",
	    "component/slider", 
	    "component/panel",
	    "component/progress",
	    "component/tab",
	    "component/loading",
	    "component/poptips", 
	    "component/dialog",
	    "component/selector",
	    "component/actionsheet"; 
	
	full:  包含frozen和vip